﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyCalcLib;

namespace MyCalcLibTests
{
    [TestClass]
    public class MyCalcTests
    {
        /// <summary>
        /// Сложение положительных чисел
        /// </summary>
        [TestMethod]
        public void Sum_10and20_30returned()
        {
            //arrange
            double x = 10, y = 20;
            double expected = 30;

            //act
            MyCalc c = new MyCalc();
            double actual = c.Sum(x, y);

            //assert
            Assert.AreEqual(expected, actual);

        }
        /// <summary>
        /// Вычитание положительных чисел
        /// </summary>
        [TestMethod]
        public void Sub_10and20_minus10returne()
        {
            //arrange
            double x = 10, y = 20;
            double expected = -10;

            //act
            MyCalc c = new MyCalc();
            double actual = c.Sub(x, y);

            //assert
            Assert.AreEqual(expected, actual);

        }
        /// <summary>
        /// Умножение положительных чисел
        /// </summary>
        [TestMethod]
     
        public void Mult_10and20_200returne()
        {
            //arrange
            double x = 10, y = 20;
            double expected = 200;

            //act
            MyCalc c = new MyCalc();
            double actual = c.Mult(x, y);

            //assert
            Assert.AreEqual(expected, actual);

        }
        /// <summary>
        /// Деление положительных чисел
        /// </summary>
        [TestMethod]        
        public void Div_20and10_2returne()
        {
            //arrange
            double x = 20, y = 10;
            double expected = 2;

            //act
            MyCalc c = new MyCalc();
            double actual = c.Div(x, y);

            //assert
            Assert.AreEqual(expected, actual);

        }
        /// <summary>
        /// Сложение отрицательных чисел
        /// </summary>
        [TestMethod]
        public void Sum_Minus10andMinus20_Minus30returned()
        {
            //arrange
            double x = -10, y = -20;
            double expected = -30;

            //act
            MyCalc c = new MyCalc();
            double actual = c.Sum(x, y);

            //assert
            Assert.AreEqual(expected, actual);

        }
        /// <summary>
        /// Вычитание отрицательных чисел
        /// </summary>
        [TestMethod]
        public void Sub_Minus10andMinus20_10returne()
        {
            //arrange
            double x = -10, y = -20;
            double expected = 10;

            //act
            MyCalc c = new MyCalc();
            double actual = c.Sub(x, y);

            //assert
            Assert.AreEqual(expected, actual);

        }
        /// <summary>
        /// Умножение отрицательных чисел
        /// </summary>
        [TestMethod]

        public void Mult_Munis10andMinus20_200returne()
        {
            //arrange
            double x = -10, y = -20;
            double expected = 200;

            //act
            MyCalc c = new MyCalc();
            double actual = c.Mult(x, y);

            //assert
            Assert.AreEqual(expected, actual);

        }
        /// <summary>
        /// Деление отрицательных чисел
        /// </summary>
        [TestMethod]
        public void Div_Minus20andMinus10_2returne()
        {
            //arrange
            double x = -20, y = -10;
            double expected = 2;

            //act
            MyCalc c = new MyCalc();
            double actual = c.Div(x, y);

            //assert
            Assert.AreEqual(expected, actual);

        }
    }
}
