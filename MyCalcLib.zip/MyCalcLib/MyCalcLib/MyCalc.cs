﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCalcLib
{
    public class MyCalc
    {
        /// <summary>
        /// Сложение
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public double Sum(double x, double y)
        {
            return x + y;
        }

        /// <summary>
        /// Вычитание
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public double Sub(double x, double y)
        {
            return x - y;
        }

        /// <summary>
        /// Умножение
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public double Mult(double x, double y)
        {
            return x * y;
        }

        /// <summary>
        /// Деление
        /// </summary>
        /// <param name="x"></param>
        /// <param name="y"></param>
        /// <returns></returns>
        public double Div(double x, double y)
        {
            return x / y;
        }
    }
}
